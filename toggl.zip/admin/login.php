<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/lang.php';
require __DIR__ . '/../includes/security.php';

// Always show the login form when this page is opened.
// Stale / wrong-role sessions used to redirect to dashboard → access denied loop.
// Opening login.php intentionally clears any previous staff session.
if (!empty($_SESSION['user_id']) && empty($_GET['stay'])) {
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
}

$error = null;
if (isset($_GET['timeout'])) {
    $error = 'Your session expired due to inactivity. Please log in again.';
} elseif (isset($_GET['reauth'])) {
    $error = 'Please log in with a valid staff account.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    // Support both password_hash (9141 schema) and password (Laravel-style).
    // Using ?? instead of empty() so this can never throw an
    // "Undefined array key" warning, no matter which column exists.
    $hash = null;
    if ($user) {
        $hash = $user['password_hash'] ?? $user['password'] ?? null;
    }

    if ($user && ($user['status'] ?? '') === 'inactive') {
        $error = t_raw('login_error');
    } elseif ($user && $hash && password_verify($password, $hash)) {
        try {
            $pdo->prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?")->execute([$user['id']]);
        } catch (Throwable $e) { /* columns may not exist */ }

        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['full_name'] ?? $user['username'];
        $rawRole = strtolower(trim((string)($user['role'] ?? '')));
        $roleMap = [
            'admin' => 'administrator',
            'dept_officer' => 'department_officer',
            'department' => 'department_officer',
            'camera' => 'camera_operator',
            'control_room' => 'camera_operator',
        ];
        $_SESSION['user_role'] = $roleMap[$rawRole] ?? $rawRole;
        $_SESSION['role'] = $_SESSION['user_role'];
        $_SESSION['user_department_id'] = $user['department_id'] ?? null;
        try {
            require_once __DIR__ . '/../includes/activity.php';
            log_activity(
                $pdo,
                'login',
                ($user['full_name'] ?? $user['username']) . ' logged in',
                'user',
                (int)$user['id'],
                null,
                ['id' => (int)$user['id'], 'name' => $user['full_name'] ?? '', 'role' => $user['role']]
            );
        } catch (Throwable $e) { /* ignore */ }
        header('Location: dashboard.php');
        exit;
    } else {
        $error = t_raw('login_error');
    }
}

$dir = t_raw('dir');
?>
<!DOCTYPE html>
<html lang="<?= $CURRENT_LANG ?>" dir="<?= $dir ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= t('login_title') ?> - <?= t('site_title') ?></title>
<link rel="icon" href="../assets/logo-adama.png">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="auth-shell">
    <div class="auth-card">
        <div class="auth-logo-row">
            <img src="../assets/logo-adama.png" alt="Adama City Administration emblem">
            <div class="auth-eyebrow">Adama City Administration</div>
            <div class="auth-title"><?= t('login_title') ?></div>
            <div class="auth-subtitle"><?= t('site_subtitle') ?></div>
            <div class="auth-roles">
                <span><?= t('role_administrator') ?></span>
                <span><?= t('role_operator') ?></span>
                <span><?= t('role_supervisor') ?></span>
                <span><?= t('role_department_officer') ?></span>
                <span><?= t('role_camera_operator') ?></span>
            </div>
        </div>
        <?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="post">
            <?= csrf_field() ?>
            <div class="auth-field">
                <label for="loginUsername">
                    <span class="auth-field-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21a8 8 0 0 0-16 0"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </span>
                    <?= t('label_username') ?>
                </label>
                <div class="auth-input-wrap">
                    <svg class="auth-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M20 21a8 8 0 0 0-16 0"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                    <input id="loginUsername" type="text" name="username" autocomplete="username" required autofocus>
                </div>
            </div>

            <div class="auth-field">
                <label for="loginPassword">
                    <span class="auth-field-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="4" y="10" width="16" height="11" rx="2"></rect>
                            <path d="M8 10V7a4 4 0 0 1 8 0v3"></path>
                        </svg>
                    </span>
                    <?= t('label_password') ?>
                </label>
                <div class="auth-input-wrap">
                    <svg class="auth-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="4" y="10" width="16" height="11" rx="2"></rect>
                        <path d="M8 10V7a4 4 0 0 1 8 0v3"></path>
                    </svg>
                    <input id="loginPassword" type="password" name="password" autocomplete="current-password" required>
                    <button type="button" class="password-toggle" id="passwordToggle" aria-label="Show password" aria-pressed="false">
                        <svg class="password-eye password-eye-show" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                        <svg class="password-eye password-eye-hide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="m3 3 18 18"></path>
                            <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"></path>
                            <path d="M9.9 4.2A10.8 10.8 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-3.1 4.5"></path>
                            <path d="M6.6 6.6C3.6 8.6 2 12 2 12s3 8 10 8a10.8 10.8 0 0 0 4.1-.8"></path>
                        </svg>
                    </button>
                </div>
            </div>
            <button type="submit"><?= t('btn_login') ?></button>
        </form>
        <p style="font-size:12.5px;color:var(--faint);text-align:center;margin-top:16px;"><?= t('login_default_hint') ?></p>
        <div style="text-align:center; margin-top:14px;"><?php render_lang_switcher(); ?></div>
    </div>
</div>
<footer style="
    text-align: center;
    padding: 22px 16px;
    margin-top: 50px;
    background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
    border-top: 1px solid #e2e8f0;
    font-family: system-ui, -apple-system, sans-serif;
">
    <div style="
        font-size: 13.5px;
        font-weight: 600;
        color: #334155;
        letter-spacing: 0.3px;
    ">
        © 2026 MNAN. All Rights Reserved.
    </div>
    <div style="
        margin-top: 6px;
        font-size: 12px;
        color: #64748b;
    ">
        Designed &amp; Developed by <span style="color:#0ea5e9; font-weight:600;">MNAN</span>
    </div>
    <div style="
        margin-top: 8px;
        font-size: 11px;
        color: #94a3b8;
    ">
        Adama City Administration · Call Center 9141
    </div>
</footer>
<script>
(function () {
    var password = document.getElementById('loginPassword');
    var toggle = document.getElementById('passwordToggle');
    if (!password || !toggle) return;

    toggle.addEventListener('click', function () {
        var visible = password.type === 'text';
        password.type = visible ? 'password' : 'text';
        toggle.setAttribute('aria-pressed', visible ? 'false' : 'true');
        toggle.setAttribute('aria-label', visible ? 'Show password' : 'Hide password');
        toggle.classList.toggle('is-visible', !visible);
    });
})();
</script>
</body>
</html>
